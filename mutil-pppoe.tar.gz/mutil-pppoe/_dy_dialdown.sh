#!/bin/sh
nvram unset nwan_${IFNAME}_status
nvram unset nwan_${IFNAME}_up_time
nvram unset nwan_${IFNAME}_ip
nvram unset nwan_${IFNAME}_gw
	
